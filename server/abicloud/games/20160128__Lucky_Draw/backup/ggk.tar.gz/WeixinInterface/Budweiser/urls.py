from django.conf.urls import patterns, url
from views import *
#from django.views.decorators.cache import cache_page

HEAD_OF_URL = '^' + SITE_RECONIZE_NAME_IN_URL
urlpatterns = patterns('',
        )
