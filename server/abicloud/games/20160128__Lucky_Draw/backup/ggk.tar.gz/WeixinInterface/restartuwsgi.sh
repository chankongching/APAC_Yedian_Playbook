killall uwsgi
uwsgi -x ../para.xml
